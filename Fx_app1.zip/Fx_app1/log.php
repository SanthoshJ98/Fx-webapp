
<?php

session_start();
   
    $hostname = "localhost";
	$username = "root";
	$password = "";
	$databaseName = "fx_app";

	$conn = mysqli_connect($hostname, $username, $password, $databaseName);
	
if(isset($_POST['submit'])){
	   
	  if(isset($_POST['user_id']))
			$myusername = $_POST['user_id'];
	  if(isset($_POST['user_pwd']))
			$mypassword = $_POST['user_pwd'];
	  
		if(!(empty($myusername)||empty($mypassword))){
		//check if input characters are valid
			if(!preg_match("/^[a-zA-z0-9]*$/",$myusername) ||!preg_match("/^[a-zA-z0-9]*$/",$mypassword)){
				?>
			<script type="text/javascript">
			alert('Enter valid user id and password');
			window.location='login.html';
			</script>
			<?php
			//header("location: login.php?error=Enter valid user id and password");
				exit();
			}
			
			$sql="select * from login where id='$myusername'";
			$result=mysqli_query($conn,$sql);		
			$resultCheck=mysqli_num_rows($result);
			$row=mysqli_fetch_array($result);
			if($resultCheck<0){
				?>
			<script type="text/javascript">
			alert('No matching id found. Try again');
			window.location='login.html';
			</script>
			<?php
			
			//	header("location: login.php?error=No matching id found. Try again");
				exit();
			}
			else{
					//dehashing the password
					$hashedPwdCheck[]=Password_VERIFY($mypassword,PASSWORD_DEFAULT);
					//update user status into db
					if($hashedPwdCheck==false){
							?>
			<script type="text/javascript">
			alert('Invalid password');
			window.location='login.html';
			</script>
			<?php
			//header("location: login.php? error=password not matched");
						exit();
					}
					else{
					
						$_SESSION['u_id']=$row['id'];
						$_SESSION['u_dept']=$row['passwd'];
	  
					$sql="update login set status='1' where id='$myusername'";		
					$result=mysqli_query($conn,$sql);
					if($result){
							?>
			<script type="text/javascript">
			alert('login success');
			window.location='index.php';
			</script>
			<?php
			//header("location: index.php?login=success");	
					}		
				}
					
			}
		}
}	
else{
	header("Location: login.html");
	exit();
}
?>