<?php
session_start();
$uid='1234';
$conn=mysqli_connect("localhost","root","","fx");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Fx app</title>
			<style>
				form input[type='text'],form input[type='email'],select{
					width: 150px;
					height: 25px;
					border: 1px silver solid;
					background:white;
					outline:none;
				}
				.inputDate{
					width:150px;
				}
				textarea{
					resize: none;
					width:250px;
					background: white;
					border: 1px silver solid; 
					outline:none;
				}
				input[type='submit'],input[type='reset']{
					background: brown;
					color: white;
					border: none;
					width: 100px;
					padding: 10px 0;
					outline:none;
				}
				input[type='submit']:hover,input[type='reset']:hover{
					background: white;
					color:brown;
				}
				input[type='text']:focus,input[type='email']:focus,select:focus{
					background: white;
					color:black;
				}
				select,input[type='date'],input[type='number']{
					width:150px;
				}
				input[type='text']:hover,input[type='email']:hover,select:focus,textarea:hover{
					border-color:lightblue;
				}
			</style>

  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
  
	<!--s<link rel="stylesheet" href="css/datepicker.css" type="text/css" />
    <link rel="stylesheet" media="screen" type="text/css" href="css/layout.css" />
   -->
	<script type="text/javascript" src="js/jquery.js"></script>
<!--	<script type="text/javascript" src="js/datepicker.js"></script>
  -->  <script type="text/javascript" src="js/eye.js"></script>
	<script type="text/javascript" src="randomid.js"></script>
    <script type="text/javascript" src="js/utils.js"></script>
    <script type="text/javascript" src="js/layout.js?ver=1.0.2"></script>
  
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.php">Home</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="index.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Deal Entry</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="noop.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">NOOP</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
          <a class="nav-link" href="mtmbuy.php">
            <i class="fa fa-fw fa-area-chart"></i>
            <span class="nav-link-text">MTM Dealwise-Buy</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="mtmdell.php">
            <i class="fa fa-fw fa-table"></i>
            <span class="nav-link-text">MTM Dealwise-Sell</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Components">
          <a class="nav-link" data-toggle="collapse" href="mtmconsolidated.php" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">MTM Dealwise-Consolidated</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Example Pages">
          <a class="nav-link" href="fxgain.php" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-file"></i>
            <span class="nav-link-text">Fx Gain</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link" href="underlying.php" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-sitemap"></i>
            <span class="nav-link-text">Underlying</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="pastperformance.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Past Performance</span>
          </a>
        </li>
		<li class="nav-item" data-toggle="tooltip" data-placement="right" title="Link">
          <a class="nav-link" href="tables.php">
            <i class="fa fa-fw fa-link"></i>
            <span class="nav-link-text">Market Rate</span>
          </a>
        </li>
 
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <form class="form-inline my-2 my-lg-0 mr-lg-2">
            <div class="input-group">
              <input class="form-control" type="text" placeholder="Search for...">
              <span class="input-group-btn">
                <button class="btn btn-primary" type="button">
                  <i class="fa fa-search"></i>
                </button>
              </span>
            </div>
          </form>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Fx app</a>
        </li>
        <li class="breadcrumb-item active">Deal-Entry</li>
      </ol> 
	</div>
      <!-- Area Chart Example-->
      <div class="card mb-3">
          <!-- Example Bar Chart Card-->
		   <script type="text/javascript">
 
 //			... etc... with .getHours(), getMinutes(), getSeconds(), getMilliseconds()
	function validate(){
window.alert('hello');
		
	if(dealentry.currencysold.value=="empty"||dealentry.currencypair.value=="empty"||dealentry.dealtype.value=="empty"||dealentry.currencybought.value=="empty"||dealentry.bank.value=="empty"||dealentry.action.value=="empty"||dealentry.booking.value=="empty"){
			alert("please select a valid option");
			return false;
		}
		else
			return true;
	}
  </script>
 
          <div class="card-body">
		  <form name="dealentry" style="
				form{
					width: 1097px;
					height:840px;
					padding: 20px;
					margin: 0 auto;
					
				}" action="" method="post">
		
			<div class="col-sm-3" style="width:200px;">	
			
 			ID<br>
			<input type="text" name="id" id="id"><br><br>
		<?php
			echo "";
			$uniqueId= time().'-'.mt_rand();
			$_GET['id']=$uniqueId;
			?>
			Deal date*<br>
			<input class="inputDate" name="dealdate" id="inputDate" value="06/14/2008"><br><br>
			Bank<br>
			<select name="bank" style="width:150px;"><option value="empty"></option><option name="sbi">SBI</option><option name="yes">YES</option><option name="hdfc">HDFC</option><option name="kotak">KOTAK</option><option name="axis">Axis</option><option name="icici">ICICI</option><option name="federal">Federal</option><option name="citi">Citi bank</option><option name="idfc">IDFC</option><option name="others">Others</option>
			</select><br><br>
			Currency Bought*<br>
			<select name="currencybought"><option name="empty" value="empty"></option><option name="usd">USD</option><option name="eur">EUR</option><option name="inr">INR</option><option name="gbp">GBP</option><option name="aed">AED</option><option name="jpy">JPY</option><option name="Others">Others</option>
			</select> <br><br>
			</div>
			
			<div style="width:200px;margin:220px;margin-top:-300px;margin-bottom:200px;">
			Currency Sold*<br><select name="currencysold"><option name="empty" value="empty"></option><option name="usd">USD</option><option name="eur">EUR</option><option name="inr">INR</option><option name="gbp">GBP</option><option name="aed">AED</option><option name="jpy">JPY</option><option name="Others">Others</option>
			</select><br><br> 
			Currency Pair*<br>
			<select name="currencypair"><option name="empty" value="empty"></option><option name="usdinr">USD/INR</option><option name="eurinr">EUR/INR</option><option name="gbpinr">GBP/INR</option><option name="aedinr">AED/INR</option><option name="jpyinr">JPY/INR</option><option name="Others">Others</option>
			</select><br><br>
			Market Action*<br>
			<select name="action" style="width:150px;"><option value="empty"></option><option>Buy</option><option>Sell</option></select><br><br>
			Spot Rate<br>
			<input type="number" name="spot"><br><br>
			</div>

			<div style="width:200px;margin:430px;margin-top:-500px;margin-bottom:200px;">
			Notional Amount(FCY)*<br><input type="number" name="notionalamount"><br><br>
			Deal Type<br><select name="dealtype" style="width:150px;><option name="empty" value="empty"></option><option name="spot">Spot</option><option name="forward">Forward</option><option name="cash">Cash</option><option name="tom">Tom</option><option name="options">Options</option><option name="Others">Others</option>
			</select><br><br>
			Deal Basis*<br>
			<select name="dealbasis"><option value="empty"></option><option>Underlying</option><option>Past Performance</option></select><br><br>
			Booking/Cancellation/Utilization<br>
			<select name="dealstatus"><option value="empty"></option><option>Booking</option><option>Cancellation</option><option>Utilization</option></select><br><br>
			</div>

			<div style="width:200px;margin:640px;margin-top:-520px;margin-bottom:200px;">
			Deal Rate*<br><input type="text" name="dealrate" ><br><br>
			Bank Deal Id*<br>
			<input type="text" name="bankid"><br><br>
			Maturity Date<br>
			<input class="inputDate" name="maturitydate" style="width:150px;" id="inputDate1" value="06/14/2008"><br><br>
			Comments<br>
			<textarea name="comments"></textarea><br><br>
			</div>

			<button name="load" value="Load" href="load.php">Load draft</button>&nbsp;&nbsp;
			<input type="submit" name="submit" value="Submit">

		  </form>
		  <br><br>
		    <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Date</th>
                  <th>Action</th>
                  <th>Spot-Rate</th>
                  <th>Quantity</th>
                  <th>Deal-type</th>
                  <th>PP or underlying</th>
                  <th>Book or cancel</th>
                  <th>Rate</th>
                  <th>Deal-Id</th>
                  <th>INR-Equiv.</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>ID</th>
                  <th>Date</th>
                  <th>Action</th>
                  <th>Spot-Rate</th>
                  <th>Quantity</th>
                  <th>Deal-type</th>
                  <th>PP or underlying</th>
                  <th>Book or cancel</th>
                  <th>Rate</th>
                  <th>Deal-Id</th>
                  <th>INR-Equiv.</th>
                </tr>
              </tfoot>
              <tbody>
				<?php
					$res=mysqli_query($conn,"select * from deal_entry where customer_id='$uid'");
					while($row=mysqli_fetch_array($res))
				echo"
                <tr onclick=''  >
                  <td>".$row[1]."</td>
                  <td>".$row[2]."</td>
                  <td>".$row[7]."</td>
                  <td>".$row[8]."</td>
                  <td>".$row[9]."</td>
                  <td>".$row[10]."</td>
                  <td>".$row[11]."</td>
                  <td>".$row[12]."</td>
                  <td>".$row[13]."</td>
                  <td>".$row[14]."</td>
                  <td>INR</td>
                </tr>";
				?>
              </tbody>
            </table>		  
		</div>
		<br><br>
	</div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Trektics 2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js"></script>
    <script src="js/sb-admin-charts.min.js"></script>
  </div>
</body>

</html>
