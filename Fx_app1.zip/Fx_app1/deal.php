<?php
	//session_start();
//	$uid=$_SESSION['u_id'];
	$uid='1234';
	$conn=mysqli_connect("localhost","root","","fx");
	
	if(isset($_POST['submit'])){
		if(isset($_POST['id']))
			$id=$_POST['id'];
		//else $id='';
		if(isset($_POST['currencysold']))
			$cs=$_POST['currencysold'];
		//else $cs='';
		if(isset($_POST['spot']))
			$spot=$_POST['spot'];
		//else $spot='';
		if(isset($_POST['notionalamount']))
			$na=$_POST['notionalamount'];
		//else $na='';
		if(isset($_POST['bankid']))
			$bid=$_POST['bankid'];
		//else $bid='';
		if(isset($_POST['dealdate']))
			$dd=$_POST['dealdate'];
		//else $dd='';
		if(isset($_POST['dealrate']))
			$dr=$_POST['dealrate'];
		if(isset($_POST['maturitydate']))
			$md=$_POST['maturitydate'];
		//else $md='';
		if(isset($_POST['currencybought']))
			$cb=$_POST['currencybought'];
		//else $cb='';
		if(isset($_POST['dealstatus']))
			$ds=$_POST['dealstatus'];
		//else $ds='';
		if(isset($_POST['dealbasis']))
			$db=$_POST['dealbasis'];
		//else $db='';
		if(isset($_POST['bank']))
			$bank=$_POST['bank'];
		//else $bank='';
		if(isset($_POST['action']))
			$act=$_POST['action'];
		//else $act='';
		if(isset($_POST['currencypair']))
			$cp=$_POST['currencypair'];
		//else $cp='';
		if(isset($_POST['dealtype']))
			$dt=$_POST['dealtype'];
		//else $cp='';
		if(isset($_POST['comments']))
			$comm=$_POST['comments'];

		$sql="INSERT INTO `deal_entry` (`customer_id`, `Id`, `Deal_date`, `Bank_id`, `currency_bought`,	`Currency_sold`, `currency_pair`, `Market_action`, `spot_rate`, `Notational_amount`, `Deal_type`, `Deal_basis`, `Deal_status`, `Deal_rate`, `Bank_deal_id`, `Maturity_date`, `Comments`) VALUES ('$uid', '$id', '$dd', '$bank', '$cb', '$cs', '$cp', '$act', '$spot', '$na', '$dt', '$db', '$ds', '$dr', '$bid', '$md', '$comm')";
		$res=mysqli_query($conn,$sql);
		if($res)
			echo "<script type='text/javascript'>alert('Deal entry form submitted');window.location.href='index.php';</script>";
		else
			echo "<script type='text/javascript'>alert('Deal entry form not submitted');window.location.href='index.php';</script>";
		}
?>