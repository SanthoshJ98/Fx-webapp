<?
$psbhostemailaddress = "hackerbparker@gmail.com"; //EDIT ME
$roothostname = "localhost";
$psbhostusername = "user"; //EDIT ME
$psbhostpassword = ""; //EDIT ME
$psbhostdatabasename = "grievances"; //EDIT ME
mysql_connect("".$roothostname."","".$psbhostusername."","".$psbhostpassword."") or die(mysql_error());
mysql_select_db("".$psbhostdatabasename."") or die(mysql_error());
?>