<?php

session_start();
   
    $hostname = "localhost";
	$username = "root";
	$password = "";
	$databaseName = "fx_app";

	$conn = mysqli_connect($hostname, $username, $password, $databaseName);
	
if(isset($_POST['submit'])){
	   
	  if(isset($_POST['user_first']))
			$first = $_POST['user_first'];
	  if(isset($_POST['user_last']))
			$last = $_POST['user_last'];
			$myusername = $_POST['user_id'];
	  if(isset($_POST['user_pwd']))
			$mypassword = $_POST['user_pwd'];
	  if(isset($_POST['user_pwd1']))
			$confirmpwd = $_POST['user_pwd1']; 
	  if(isset($_POST['user_email']))
			$email = $_POST['user_email'];
		if(!($mypassword==$confirmpwd)){
			?>
			<script type="text/javascript">alert('confirm password not matching');</script>
			<?php
			header('location:register.html');
		}
	  
		//get all data submitted from form
		
		
		
		if(!(empty($first)|| empty($last)|| empty($email)|| empty($myusername)||empty($mypassword))){
		{
			//check if input characters are valid
			if(!preg_match("/^[a-zA-z]*$/",$first) ||!preg_match("/^[a-zA-z]*$/",$last)){
					?>
			<script type="text/javascript">
			alert('Enter valid user id and password');
			window.location='register.html';
			</script>
			<?php
			exit();
			}
			else{
				//check if email is valid
				if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
					?>
			<script type="text/javascript">
			alert('Enter valid email id');
			window.location='register.html';
			</script>
			<?php
			exit();
			}
			
			$sql="select * from login where id='$myusername'";
			$result=mysqli_query($conn,$sql);		
			$resultCheck=mysqli_num_rows($result);
			if($resultCheck>0){
					?>
			<script type="text/javascript">
			alert('User is already taken. Try another id');
			window.location='register.html';
			</script>
			<?php
						exit();
			}
			else{
					//hashing the password
					$hashedPwd=Password_hash($mypassword,PASSWORD_DEFAULT);
					//insert user into db
					
					}
					 
					$sql="insert into login (first_name,last_name,id,email,passwd) values ('$first','$last','$myusername', '$email', '$hashedPwd')";   
					$res=mysqli_query($conn,$sql);
                                        ?>
			<script type="text/javascript">
			alert('Sign up success');
			window.location='login.html';
			</script>;
		<?php
            }
					
					
			
			//header("location: login.php?sign up=success");
			
                }}
	}
else{
	header("Location: register.html");
	exit();
}
?>