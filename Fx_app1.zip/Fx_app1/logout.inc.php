 <?php
	 session_start();
	 $uid=$_SESSION['u_id'];

	 $dbServername = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbName = "grievances";

	$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
	$sql="update login set status='0' where id='$uid'";
	$result=mysqli_query($conn,$sql);
	
 header("Location: index.php");
	echo "<script type='text/javascript'>alert('logged out')</script>";
	 session_unset();
	 session_destroy();	
	
exit();
		
?>