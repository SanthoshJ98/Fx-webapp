$(document).ready(function(){
	$.ajax({
		url: "http://localhost/Fx_app1/data1.php",
		method: "GET",
		success: function(data) {
			console.log(data);
			var c_date = [];
			var count = [];
			
			for(var i in data) {
				c_date.push("date"+data[i].c_date);
				count.push(data[i].count);
			}

			var chartdata = {
				labels: c_date,
				datasets : [
					{
						label: 'Count of complaints',
						/*backgroundColor: 'rgba(200, 200, 200, 0.75)',
						borderColor: 'rgba(200, 200, 200, 0.75)',
						hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
						hoverBorderColor: 'rgba(200, 200, 200, 1)',*/
						
						  lineTension: 0.3,
      backgroundColor: "rgba(2,117,216,0.2)",
      borderColor: "rgba(2,117,216,1)",
      pointRadius: 5,
      pointBackgroundColor: "rgba(2,117,216,1)",
      pointBorderColor: "rgba(255,255,255,0.8)",
      pointHoverRadius: 5,
      pointHoverBackgroundColor: "rgba(2,117,216,1)",
      pointHitRadius: 20,
      pointBorderWidth: 2,
    
						data: count
					}
				]
			};

			var ctx = $("#mycanvas");

			/*var barGraph = new Chart(ctx, {
				type: 'line',
				data: chartdata
			});*/
			
			myPieChart=new Chart(ctx,{
				type:"pie",
				data:{
					labels:["Blue","Red","Yellow","Green"],
					datasets:[{
						data:[12.21,15.58,11.25,8.32],
						backgroundColor:["#007bff","#dc3545","#ffc107","#28a745"]
						}]
					}
				});
		},
		error: function(data) {
			console.log(data);
		}
	});
});