<?php
echo "<!DOCTYPE html>
<html>
	<head>
		<title>Deal entry form</title>
	</head>
	<body>
		<div id='head'>
		<h3>Deal entry form</h3>
		</div>
		<div id='table'>
		<table border='1'>
			<tr><th>ID</th><th>Deal Date*</th><th>Bank*</th><th>Currency Bought*</th><th>Currency Sold*</th><th>Currency Pair*</th><th>Market Action(Buy/sell)</th><th>Spot rate*</th>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
			</tr>	</table>
			</div>
			</body>
			</html>"
			?>